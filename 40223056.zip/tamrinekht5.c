//نگین عینی پور-40223056
#include <stdio.h>
int main(){
int n;
do
{
    printf("Please enter a number: ");
    scanf("%d",&n);
} while (n==0);
char sentence[n+1];
printf("Please enter a phrase with n charactors: ");
scanf("%s",sentence);
for (int k=0;k<n;k++)
{
    for(int i=0; i<n; i++)
    {
        while(sentence[i]==sentence[i+1])
        {
            if(sentence[i]==sentence[i+1])
            {
                for(int j=i; j<n; j++)
                sentence[j]=sentence[j+2];
            
            }
        printf("%s\n",sentence);
        }
    }
}
    return 0;
}